# 🎉 ¡Bienvenido a los ejercicios!

Este archivo es parte de tu curso de Claude Code en Español.

## ¿Qué hay en esta carpeta?

Aquí encontrarás archivos para practicar durante las lecciones:

- **mi-primer-archivo.txt** - Tu primera lectura (Lección 2)
- **secreto.txt** - Un archivo escondido para explorar
- **notas.md** - Archivos que crearás durante el curso

## Tips para los ejercicios

1. No tengas miedo de experimentar
2. Si algo sale mal, siempre puedes volver a empezar
3. Pregunta a Claude cualquier duda

---

*Archivo creado automáticamente por el curso*
